﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("College Selected is: " & ComboBox1.SelectedItem)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Vidyalankar Polytechnic")
        ComboBox1.Items.Add("St. Xavier's College")
        ComboBox1.Items.Add("Willson College")
        ComboBox1.Items.Add("Mithibai College")
    End Sub

End Class
