﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add(12)
        ComboBox1.Items.Add(10)
        ComboBox1.Items.Add(5)
        ComboBox1.Items.Add(6)

        ComboBox2.Items.Add(12)
        ComboBox2.Items.Add(10)
        ComboBox2.Items.Add(5)
        ComboBox2.Items.Add(6)

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num1 As Integer = Integer.Parse(ComboBox1.SelectedItem)
        Dim num2 As Integer = Integer.Parse(ComboBox2.SelectedItem)
        Dim num3 As Double
        num3 = (num1 + num2) / 2
        MsgBox("The Average is: " & num3)
    End Sub
End Class
