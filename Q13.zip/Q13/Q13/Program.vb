Imports System

Module Module1
    Sub Main()
        Console.Write("Enter the radius of the circle: ")
        Dim radius As Double = Double.Parse(Console.ReadLine())
        Dim circle As New Circle(radius)
        Console.WriteLine("Area of circle with radius {0} is {1:F2}", radius, circle.GetArea())
        Console.ReadLine()
    End Sub
End Module

Class Circle
    Private radius As Double
    Public Sub New(ByVal r As Double)
        radius = r
    End Sub
    Public Function GetArea() As Double
        Return Math.PI * radius * radius
    End Function
End Class