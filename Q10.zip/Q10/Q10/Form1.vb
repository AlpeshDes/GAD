﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num, revNum As Integer
        num = Integer.Parse(TextBox1.Text)
        ReverseNum(num, revNum)
        Label3.Text = revNum.ToString()
    End Sub
    Sub ReverseNum(ByVal num As Integer, ByRef revNum As Integer)
        Dim remainder As Integer
        revNum = 0
        While num > 0
            remainder = num Mod 10
            revNum = (revNum * 10) + remainder
            num = num \ 10
        End While
    End Sub
End Class
