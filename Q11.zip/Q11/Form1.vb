﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num1 As Integer = Integer.Parse(TextBox1.Text)
        Dim num2 As Integer = Integer.Parse(TextBox2.Text)
        Dim largestNumber As Integer = FindLargest(num1, num2)
        Label1.Text = "The Largest Number is: " & largestNumber.ToString()
    End Sub
    Private Function FindLargest(ByVal num1 As Integer, ByVal num2 As Integer) As Integer
        Dim largestNumber As Integer = num1
        If num2 > largestNumber Then
            largestNumber = num2
        End If
        Return largestNumber
    End Function
End Class
