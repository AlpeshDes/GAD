Imports System

'Write a Program using select case statement using Console
Module Module1
    Sub Main()
        Dim grade As String
        Console.WriteLine("Enter Your grade")
        grade = Console.ReadLine()
        Select Case grade
            Case Is >= 75
                Console.WriteLine("Passed with Distinction")
            Case Is >= 50
                Console.WriteLine("First class")
            Case Is >= 35
                Console.WriteLine("pass class")
            Case Else
                Console.WriteLine("Fail")
        End Select
        Console.ReadLine()
    End Sub
End Module