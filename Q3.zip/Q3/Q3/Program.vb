Imports System

Module Program
    Sub Main(args As String())

        Dim i, j, c As Integer
        c = 0
        i = 2
        While (i <= 100)
            j = 2
            While (j < i)
                If (i Mod j = 0) Then
                    Exit While
                ElseIf (i = j + 1) Then
                    Console.WriteLine(i)
                End If
                j = j + 1
            End While
            i = i + 1
        End While
        Console.ReadLine()

    End Sub
End Module
