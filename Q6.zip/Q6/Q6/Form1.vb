﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim n As Integer
        Dim c As Integer
        Dim f As Long
        n = Val(TextBox1.Text)
        f = 1
        c = 1
        While c <= n
            f = f * c
            c = c + 1
        End While
        MsgBox("Factorial: " & n & " = " & f)
    End Sub

End Class
