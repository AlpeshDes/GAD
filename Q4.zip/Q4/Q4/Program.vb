Imports System

Module Program
    Sub Main(args As String())


        Dim num, temp, r, s, t As Integer

        Console.WriteLine(" Armstrong Number Between 1 to 500: ")
        For num = 1 To 500
            temp = num
            s = 0
            For t = 0 To num
                r = temp Mod 10
                s = (r * r * r) + s
                temp = temp \ 10
            Next
            If num = s Then
                Console.WriteLine(num)
            End If
        Next
        Console.ReadKey()
    End Sub
End Module
