﻿Imports System.Text.RegularExpressions
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim regex As Regex = New Regex("^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")
        Dim isValid As Boolean = regex.IsMatch(TextBox1.Text.Trim)
        If isValid Then
            MessageBox.Show("valid Email.")
        Else
            MessageBox.Show("INvalid email")

        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Not Regex.Match("111-111-1111", "^[1-9]" &
         "\d{2}-[1-9]\d{2}-\d{4}$").Success Then
            MessageBox.Show("inValid phone number")
        Else
            MessageBox.Show("valid Phone Number")

            Return
        End If

    End Sub
End Class
